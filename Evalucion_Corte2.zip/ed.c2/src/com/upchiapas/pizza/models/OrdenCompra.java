package com.upchiapas.pizza.models;

public class OrdenCompra {

	private int id;
	private String pedido;
	private int EspecialidadPizza;
	
	public OrdenCompra() {
		nombrePedido = "";
		id = 0;
		EspecialidadPizza = 0;
	}

	public OrdenCompra(String np, int id2, int tp) {
		Pedido = np;
		id = id2;
		EspecialidadPizza = tp;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPedido() {
		return Pedido;
	}

	public void setPedido(String Pedido) {
		this.Pedido = Pedido;
	}

	public int getEspecializacionPizza() {
		return EspecialidadPizza;
	}

	public void setEspecialidadPizza(int EspecialidadPizza) {
		this.EspecialidadPizza = EspecialidadPizza;
	}


	
	
	
}
