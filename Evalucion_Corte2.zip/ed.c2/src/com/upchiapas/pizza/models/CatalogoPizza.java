package com.upchiapas.pizza.models;

public class CatalogoPizza {

	public CatalogoPizza(){
	}
	
	public void nombresPizza(String[] nombre, int arraylength) {
		String [] recibo = new String [arraylength];
		for(int i =0; i< recibo.length; i++) {
			recibo[i] = nombre[i];
		}
		
		for(int i =0; i< recibo.length; i++) {
			System.out.println("Pizza tipo: "+ recibo[i]);
		}
		
	}
	
	
}